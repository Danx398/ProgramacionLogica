class Operador{
    constructor(dato){
        this.validacion(dato);
    }   
}
class Son extends Operador{
    validacion(dato){
        let operador_de_nulo = dato == null ? `el valor es nulo`:dato == '' ? `el valor esta vacio`: typeof(dato) == "number" ? `el valor es un numero`:typeof(dato) == "string"?`Es una cadena`:Object.values(dato)?`Es un objeto`:`no es un objeto`;
        dato=== undefined ? document.write(`es undefined`):document.write(operador_de_nulo);
    }
}
const terneario = new Son({hola:"Holis"});
