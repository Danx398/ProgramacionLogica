/* Se contruye nuestro mapa el cual es un objeto */
const datos = new Map();
datos.set('nombre','Daniel');
/* El .set asigna al mapa en la posición que corresponda para que se llene en automatico el valor
=> Es infinito, se puede llenar las veces que sea necesario
*/
datos.set('edad','21');
datos.set(1,"Holis");
console.log(datos.get(1));
